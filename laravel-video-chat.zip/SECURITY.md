## Reporting a Vulnerability

You can report a vulenerability to [scientificgh@gmail.com](mailto:scientificgh@gmail.com).

I will respond with a patch.

Even though this repository contains demo projects, we could use
the vulnerabilities identified to teach users how to create secure Video Chat Applications.