

<?php $__env->startSection('content'); ?>
    <video-chat :allusers="<?php echo e($users); ?>" :authUserId="<?php echo e(auth()->id()); ?>" turn_url="<?php echo e(env('TURN_SERVER_URL')); ?>"
        turn_username="<?php echo e(env('TURN_SERVER_USERNAME')); ?>" turn_credential="<?php echo e(env('TURN_SERVER_CREDENTIAL')); ?>" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.4\htdocs\video_chat\laravel-video-chat\resources\views/video-chat.blade.php ENDPATH**/ ?>