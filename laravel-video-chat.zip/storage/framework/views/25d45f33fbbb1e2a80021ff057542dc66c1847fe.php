

<?php $__env->startSection('scripts'); ?>
    <meta name="description" content="Build A Scalable Video Chat Application With Agora" />
    <meta name="keywords" content="Video Call, Agora, Laravel, Real Time Engagement" />
    <meta name="author" content="Kofi Obrasi Ocran" />
    <script src="https://cdn.agora.io/sdk/release/AgoraRTCSDK-3.3.1.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <agora-chat :allusers="<?php echo e($users); ?>" authuserid="<?php echo e(auth()->id()); ?>" authuser="<?php echo e(auth()->user()->name); ?>"
        agora_id="<?php echo e(env('AGORA_APP_ID')); ?>" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.4\htdocs\video_chat\laravel-video-chat\resources\views/agora-chat.blade.php ENDPATH**/ ?>